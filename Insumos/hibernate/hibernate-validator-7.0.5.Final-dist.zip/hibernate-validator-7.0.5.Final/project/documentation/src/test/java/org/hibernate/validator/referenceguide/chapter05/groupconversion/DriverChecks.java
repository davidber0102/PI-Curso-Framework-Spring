package org.hibernate.validator.referenceguide.chapter05.groupconversion;

public interface DriverChecks {
}
