package org.hibernate.validator.referenceguide.chapter12.constraintapi;

import java.util.Date;

public interface Tournament {
	Date getTournamentDate();
}


