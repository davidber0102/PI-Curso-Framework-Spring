package org.hibernate.validator.referenceguide.chapter03.crossparameter;

public class Person {
}
