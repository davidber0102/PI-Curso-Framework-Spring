package org.hibernate.validator.referenceguide.chapter03.validation;

public class Passenger {
}
